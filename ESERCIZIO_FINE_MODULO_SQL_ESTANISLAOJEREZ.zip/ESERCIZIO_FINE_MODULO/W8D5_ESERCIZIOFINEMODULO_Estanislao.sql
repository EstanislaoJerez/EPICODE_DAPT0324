-- Creazione Database ToysGroup
-- create schema DAPT0324_W8D5_EsercizioFinemodulo_EstanislaoJerez;
-- USE DAPT0324_W8D5_EsercizioFinemodulo_EstanislaoJerez;
-- Crea e popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate). 
-- Creazione tabelle
CREATE TABLE Prodotti (
ID_Prodotto INT PRIMARY KEY,
Nome_Prodotto VARCHAR (50),
Categoria VARCHAR (50),
Prezzo_Unitario DECIMAL (10, 2)
);

CREATE TABLE Region (
ID_Regione INT PRIMARY KEY,
Regione VARCHAR (10)
);

CREATE TABLE Sales (
ID_Ordine INT PRIMARY KEY,
Data_Ordine DATE,
ID_Prodotto INT,
Quantità DECIMAL (10, 0),
Prezzo_Totale DECIMAL (10, 2), 
ID_Regione INT,
FOREIGN KEY (ID_Prodotto) REFERENCES Prodotti (ID_Prodotto),
FOREIGN KEY (ID_Regione) REFERENCES Region(ID_Regione)
);
-- Popolamento tabelle 
INSERT INTO prodotti (Id_prodotto, nome_Prodotto, Categoria, Prezzo_unitario) VALUES
(1, '4strike', 'triciclo', 64.90),
(2, 'cluedo', 'gioco di società', 31.99),
(3, 'unicorno 100cm', 'peluche', 29.99),
(4, 'meccano 100 pz', 'giochi di costruzione', 49.99),
(5, 'set lego star wars: Millennium Falcon', 'giochi di costruzione', 849.99);
select * from prodotti;
INSERT INTO Region (ID_Regione, Regione) VALUES
(1, 'Lazio'),
(2, 'Puglia'),
(3, 'Umbria'),
(4, 'Liguria');
select * from Region;

INSERT INTO Sales (id_ordine, data_ordine, id_Prodotto, quantità, prezzo_totale, id_regione) VALUES
(1, '2024-07-20', 1, 3, 194.70, 1),
(2, '2024-07-20', 1, 1, 64.90, 2),
(3, '2024-07-22', 3, 2, 59.98, 3),
(4, '2024-07-23', 4, 4, 199.96, 3),
(5, '2024-07-26', 2, 1, 31.99, 3),
(6, '2024-07-26', 2, 1, 31.99, 2);
select * from Sales;


-- Dopo la creazione e l’inserimento dei dati nelle tabelle, esegui e riporta delle query utili a: 
-- 1. Verificare che i campi definiti come PK siano univoci.  
SELECT Id_prodotto, COUNT(*)
FROM Prodotti
GROUP BY Id_prodotto
HAVING COUNT(*) > 1;

SELECT ID_Regione, COUNT(*)
FROM Region
GROUP BY ID_Regione
HAVING COUNT(*) > 1;

SELECT id_ordine, COUNT(*)
FROM Sales
GROUP BY id_ordine
HAVING COUNT(*) > 1;

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno
SELECT 
    p.nome_Prodotto,
    YEAR(s.data_ordine) AS Anno,
    SUM(s.prezzo_totale) AS FatturatoTotale
FROM 
    Sales s
INNER JOIN 
    Prodotti p ON s.ID_Prodotto = p.ID_Prodotto
GROUP BY 
    p.nome_Prodotto, YEAR(s.data_ordine)
ORDER BY 
    p.nome_Prodotto, Anno;
    
-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.
SELECT 
    r.Regione,
    YEAR(s.data_ordine) AS Anno,
    SUM(s.prezzo_totale) AS FatturatoTotale
FROM 
    Sales s
INNER JOIN 
    Region r ON s.ID_Regione = r.ID_Regione
GROUP BY 
   r.Regione, YEAR(s.data_ordine)
ORDER BY 
    YEAR(s.data_ordine), SUM(s.prezzo_totale) DESC;
    
-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 
SELECT 
    p.Categoria,
    SUM(s.quantità) AS TotaleQuantitàVenduta
FROM 
    Sales s
INNER JOIN 
    Prodotti p ON s.ID_Prodotto = p.ID_Prodotto
GROUP BY 
    p.Categoria
ORDER BY 
    TotaleQuantitàVenduta DESC;
    
-- RISPOSTA: secondo l'analisi della query sopra descritta, i due articoli maggiormente richiesti dal mercato appartengono 
-- alla categoria triciclo e giochi di costruzione.
    
-- 5. Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? 
-- Proponi due approcci risolutivi differenti
-- Primo approccio: Subquery NOT IN 
SELECT 
    p.ID_Prodotto,
    p.nome_Prodotto
FROM 
    Prodotti p
WHERE 
    p.ID_Prodotto NOT IN (SELECT s.ID_Prodotto FROM Sales s);
    
-- secondo approccio left join is null
    SELECT 
    p.id_prodotto,
    p.nome_Prodotto
FROM 
    Prodotti p
LEFT JOIN 
    Sales s ON p.id_prodotto = s.id_Prodotto
WHERE 
    s.id_Prodotto IS NULL;

-- RISPOSTA: Dalle interrogazioni del DB il prodotto non ancora venduto è il 5° "Set lego star wars: Millennium Falcon"
    

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
SELECT 
    p.ID_Prodotto,
    p.nome_Prodotto,
    MAX(s.data_ordine) AS UltimaDataVendita
FROM 
    Prodotti p
INNER JOIN 
    Sales s ON p.ID_Prodotto = s.ID_Prodotto
GROUP BY 
    p.ID_Prodotto,
    p.nome_Prodotto
ORDER BY 
    UltimaDataVendita DESC;







